



<?php
session_start();
if (isset($_SESSION['prod'])) {
$prod=$_SESSION['prod'];
}
if (isset($_SESSION['price'])) {
$pri=$_SESSION['price'];}
?>

<html>
    <head>
        <title>organic-Sky grocerer</title>
        <link rel="stylesheet" type="text/css" href="organic.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1200px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
    </head>
    <body>
      <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>.</p>
</div>
</div>
<div id="main-header">
<div id="logo">
<span id="ist">SKY</span><span id="iist">Grocerer.com</span>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="first.php">Cart</a></li>
        <li><a href="login1.php">Login</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="index.html">Home</a>
        <a href="organic1.php"s>New launches</a>
        <a href="organic1.php">Organic</a>
        <a href="contact.html">About Us</a>
        </nav>
        <div class="org">
            <center><h1><i>Organic Store</i></h1></center></div>
        <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="images/daawat.jpg" style="width:100%">
  <div class="text">Caption Text</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="images/fog.jpg" style="width:100%">
  <div class="text">Caption Two</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="images/saf.jpg" style="width:100%">
  <div class="text">Caption Three</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 3000); // Change image every 2 seconds
}
</script>
        <div class="fea">
        <h2><center>Featured Products</center></h2>
            <hr>
        </div>
    
        <div class="prod-container">
        <div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                                    <form method="POST" action="insertcart.php">
                <p>Dove Shampoo 650ml</p><input type="hidden" name="product" value="Dove Shampoo 650ml">
                    <p style="color:#fff;font-weight:bold;">price : 359</p><input type="hidden" name="price" value="RS 359">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div>
             <div class="prod-box">
            <img src="images/pro_366220.jpg" alt="Arhar dal">
            <div class="prod-trans">
                <div class="prod-feature">
                                                        <form method="POST" action="insertcart.php">

                <p>Arhar dal 1kg</p><input type="hidden" name="product" value="Arhar dal 1kg">
                    <p style="color:#fff;font-weight:bold;">price : 90</p><input type="hidden" name="price" value="RS 90">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/tata.webp" alt="Tata salt">
            <div class="prod-trans">
                <div class="prod-feature">
                                                        <form method="POST" action="insertcart.php">

                <p>Tata salt 1kg</p><input type="hidden" name="product" value="Tata salt 1kg">
                    <p style="color:#fff;font-weight:bold;">price : 19</p><input type="hidden" name="price" value="RS 19">
                    <input type="submit" value="Add to cart">
                    </form>`
                                                            </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/india.webp" alt="india gate">
            <div class="prod-trans">
                <div class="prod-feature">   <form method="POST" action="insertcart.php">
                <p>India gate basmati rice 5kg</p><input type="hidden" name="product" value="India gate basmati rice 5kg">
                    <p style="color:#fff;font-weight:bold;">price : 485</p><input type="hidden" name="price" value="RS 485">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/for.jpg" alt="fortune">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="insertcart.php">
                <p>Fortune soyabean oil 1lt.</p><input type="hidden" name="product" value="Fortune soyabean oil 1lt">
                    <p style="color:#fff;font-weight:bold;">price : 120</p><input type="hidden" name="price" value="RS 120">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/pro_211408.webp" alt="surf excel">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="insertcart.php">
                <p>Surf excel 3*2kg</p><input type="hidden" name="product" value="Surf excel 3*2kg">
                    <p style="color:#fff;font-weight:bold;">price : 960</p><input type="hidden" name="price" value="RS 960">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/col.webp" alt="colgate">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Colgate herbal 200gm</p>
                    <p style="color:#fff;font-weight:bold;">price : 88</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/parle.jpg" alt="parle">
            <div class="prod-trans">
                <div class="prod-feature">
                     <form method="POST" action="insertcart.php">
                <p>Parle-G 800gm</p><input type="hidden" name="product" value="Parle-G 800gm">
                    <p style="color:#fff;font-weight:bold;">price : 60</p><input type="hidden" name="price" value="RS 60">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/cofee.webp" alt="coffee">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Nescafe coffee 200gm</p>
                    <p style="color:#fff;font-weight:bold;">price : 250</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/tide.webp" alt="tide">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Tide 6kg</p>
                    <p style="color:#fff;font-weight:bold;">price : 484</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div>
             <div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Dove Shampoo 650ml</p>
                    <p style="color:#fff;font-weight:bold;">price : 359</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div><div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Dove Shampoo 650ml</p>
                    <p style="color:#fff;font-weight:bold;">price : 359</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div><div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Dove Shampoo 650ml</p>
                    <p style="color:#fff;font-weight:bold;">price : 359</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div><div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Dove Shampoo 650ml</p>
                    <p style="color:#fff;font-weight:bold;">price : 359</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div><div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Dove Shampoo 650ml</p>
                    <p style="color:#fff;font-weight:bold;">price : 359</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div>
                 </div> <div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Dove Shampoo 650ml</p>
                    <p style="color:#fff;font-weight:bold;">price : 359</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/pro_19323.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Dove Shampoo 650ml</p>
                    <p style="color:#fff;font-weight:bold;">price : 359</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
            </div>
             <div class="prod-box">
            <img src="images/pro_366220.jpg" alt="Arhar dal">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Arhar dal 1kg</p>
                    <p style="color:#fff;font-weight:bold;">price : 90</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div> 
             <div class="prod-box">
            <img src="images/pro_366220.jpg" alt="Arhar dal">
            <div class="prod-trans">
                <div class="prod-feature">
                <p>Arhar dal 1kg</p>
                    <p style="color:#fff;font-weight:bold;">price : 90</p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
                 </div> 
   
    <div class="prod-box">
           


<?php
    //DB details
    $dbHost     = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName     = 'akash';
    
    //Create connection and select DB
    $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    
    //Check connection
    if($db->connect_error){
       die("Connection failed: " . $db->connect_error);
    }
    
    //Get image data from database
    $result = $db->query("SELECT image FROM images WHERE product_id =9");
    
    if($result->num_rows > 0){
        $imgData = $result->fetch_assoc();
        
        //Render image
        header("Content-type: image/jpg"); 
        echo $imgData['image']; 
    }else{
        echo 'Image not found...';
    }
?>




            <div class="prod-trans">
                <div class="prod-feature">
                <p><?php echo "$prod";?></p>
                    <p style="color:#fff;font-weight:bold;">price : <?php echo "$pri";?></p>
                    <input type="submit" value="Add to cart">
                </div>
            </div>
            </div>
           
               </div>
    
        <div id="footer">
    <div class="container">
        <div class="footer_sub">
            <h2>About</h2>
            <h4>Online grocery shopping in India</h4>
            <p>This is an E-commerce webite designed in HTML and CSS using Java script also.Order online. All your favourite products from the low price online supermarket for grocery home delivery in Jaipur Lowest prices guaranteed on Patanjali, Aashirvaad, Maggi, Saffola, Fortune, Nestle, Amul, Surf Excel,Haldiram's and others.</p>
            <h4>One stop shop for all your daily needs</h4>
            <p>Sky grocerer is low-price online supermarket that allows you to order products across categories like grocery,and gets them delivered to your doorstep.</p>
        </div>
        <div class="footer_sub_2">
             <h2>Social links:</h2>
        <ul><h4> <a href="#">Facebook</a>   <a href="#">Instagram</a>   <a href="#">linkdin</a>  <a href="#">Twitter</a></h4></ul>
        </div>
        <div class="footer_sub_3">
            <center>
            <h2>Subscribe Us</h2>
        <input type="text" name="subs" placeholder="Enter your email" class="subs">
                <input type="submit" name="submit_btn" value="subscribe" class="sub_btn">
                <p class="sub_p">Enter your Email id to get notifications from us.</p>
            </center>
        </div>
            </div>
        </div>
        </div>
    </body>
</html>