
<html>
    <head>
        <title>login-Sky grocerer</title>
        <link rel="stylesheet" type="text/css" href="daily.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            .adm{
                float: left;
                margin: -65 340px;
            }
            .text {
    width: 400px;
    height: 50px;
    margin: -50 150px;
    background: #fff;
    border-radius: 10px;
    float:left;
    padding-left: 15px;
}
            .submit {
    width: 140px;
    height: 50px;
    border-radius: 20px;
    margin: -50 720px;
                float: right;
    border: none;
    color: #fff;
    background: #1aaa1a;
    margin-left:10px;
}
        </style>
    </head>
    <body>
      <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>.</p>
</div>
</div>
<div id="main-header">
<div id="logo">
<span id="ist">SKY</span><span id="iist">Grocerer.com</span>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="#">Cart</a></li>
        <li><a href="">Login</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="index.html">Home</a>
        <a href="organic.html">New launches</a>
        <a href="organic.html">Organic</a>
        <a href="contact.html">About Us</a>
        </nav>
        <div class="fea">
        <h1><center>Admin Page</center></h1><hr>
        </div>
           
        <h2 style="color:brown;">Add product(Select category):</h2><div class="adm"> <h2><a href="adminadd.php" style="text-decoration:none; color:#1aaa1a;">Organic</a> &nbsp; &nbsp;   <a href="login1.php" style="text-decoration:none; color:#1aaa1a;">Daily Essential</a>  &nbsp; &nbsp;  <a href="login1.php" style="text-decoration:none; color:#1aaa1a;">Indian grocery</a></h2>
        </div>
        <hr>
        <h2 style="color:brown;">Search user:</h2><form method="POST" action="adminshow.php"><input class="text" name="email" placeholder="Enter Email" required><input class="submit" type="submit" name="submit" value="Search"></form><br>
        <hr>
        
            <div id="footer">
    <div class="container">
        <div class="footer_sub">
            <h2>About</h2>
            <h4>Online grocery shopping in India</h4>
            <p>This is an E-commerce webite designed in HTML and CSS using Java script also.Order online. All your favourite products from the low price online supermarket for grocery home delivery in Jaipur Lowest prices guaranteed on Patanjali, Aashirvaad, Maggi, Saffola, Fortune, Nestle, Amul, Surf Excel,Haldiram's and others.</p>
            <h4>One stop shop for all your daily needs</h4>
            <p>Sky grocerer is low-price online supermarket that allows you to order products across categories like grocery,and gets them delivered to your doorstep.</p>
        </div>
        <div class="footer_sub_2">
             <h2>Social links:</h2>
        <ul><h4> <a href="#">Facebook</a>   <a href="#">Instagram</a>   <a href="#">linkdin</a>  <a href="#">Twitter</a></h4></ul>
        </div>
        <div class="footer_sub_3">
            <center>
            <h2>Subscribe Us</h2>
        <input type="text" name="subs" placeholder="Enter your email" class="subs">
                <input type="submit" name="submit_btn" value="subscribe" class="sub_btn">
                <p class="sub_p">Enter your Email id to get notifications from us.</p>
            </center>
        </div>
             </div>
        </div>
        </div>
    </body>
</html>