<?php
//Include GP config file && User class
include_once 'gpConfig.php';
include_once 'User.php';

if(isset($_GET['code'])){
	$gClient->authenticate($_GET['code']);
	$_SESSION['token'] = $gClient->getAccessToken();
	header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
}

if (isset($_SESSION['token'])) {
	$gClient->setAccessToken($_SESSION['token']);
}

if ($gClient->getAccessToken()) {
	//Get user profile data from google
	$gpUserProfile = $google_oauthV2->userinfo->get();
	
	//Initialize User class
	$user = new User();
	
	//Insert or update user data to the database
    $gpUserData = array(
        'oauth_provider'=> 'google',
        'oauth_uid'     => $gpUserProfile['id'],
        'first_name'    => $gpUserProfile['given_name'],
        'last_name'     => $gpUserProfile['family_name'],
        'email'         => $gpUserProfile['email'],
        'gender'        => $gpUserProfile['gender'],
        'locale'        => $gpUserProfile['locale'],
        'picture'       => $gpUserProfile['picture'],
        'link'          => $gpUserProfile['link']
    );
    $userData = $user->checkUser($gpUserData);
	
	//Storing user data into session
	$_SESSION['userData'] = $userData;
	
	//Render facebook profile data
    if(!empty($userData)){
        $output = '<h1>Google+ Profile Details </h1>';
        $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
        $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
        $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
        $output .= '<br/>Email : ' . $userData['email'];
        $output .= '<br/>Gender : ' . $userData['gender'];
        $output .= '<br/>Locale : ' . $userData['locale'];
        $output .= '<br/>Logged in with : Google';
        $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
        $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
    }else{
        $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
    }
} else {
	$authUrl = $gClient->createAuthUrl();
    ?>
<html>
    <head>
        <title>login-Sky grocerer</title>
        <link rel="stylesheet" type="text/css" href="login.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
      <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>.</p>
</div>
</div>
<div id="main-header">
<div id="logo">
<span id="ist">SKY</span><span id="iist">Grocerer.com</span>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="#">Cart</a></li>
        <li><a href="">Login</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="index.html">Home</a>
        <a href="#">New launches</a>
        <a href="organic.html">Organic</a>
        <a href="#">About Us</a>
        </nav>
        <form method="POST" action="login.php">
        <div class="boxed">
<div id="containe">   
    <h3>Login in to your account</h3>
<input class="text" name="email" placeholder="Enter Email" required>
    <input class="password" name="pass" type="password" placeholder="Enter Password" required>
    <div id="forgot">
    <a href="#">Forgot password?</a><br>
        </div>
        <input class="submit" type="submit" name="submit" value="submit">
    
    <?php
   $output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="login.png" alt=""/></a>';
}
?>
    
     <div class="signup"><?php echo $output; ?></div>
    <h5>New to Sky grocerer?</h5>
    <div class="signup">
    <a href="signup.html">Signup</a> &nbsp; &nbsp; &nbsp;or
        &nbsp; &nbsp; &nbsp; <a href="admin.php">Admin Login</a>
    </div>
   <div class="info">
 <h3> You will love to shop with us</h3>
<h4>- Wide selection of products<br>
    <br>
- Quality and service you'll love<br>
    <br>
    - On time delivery guarantee</h4>
    </div>
    </div>
        </div>
        </form>
        </div>
         <div id="footer">
    <div class="container">
        <div class="footer_sub">
            <h2>About</h2>
            <h4>Online grocery shopping in India</h4>
            <p>This is an E-commerce webite designed in HTML and CSS using Java script also.Order online. All your favourite products from the low price online supermarket for grocery home delivery in Jaipur Lowest prices guaranteed on Patanjali, Aashirvaad, Maggi, Saffola, Fortune, Nestle, Amul, Surf Excel,Haldiram's and others.</p>
            <h4>One stop shop for all your daily needs</h4>
            <p>Sky grocerer is low-price online supermarket that allows you to order products across categories like grocery,and gets them delivered to your doorstep.</p>
        </div>
        <div class="footer_sub_2">
             <h2>Social links:</h2>
        <ul><h4> <a href="#">Facebook</a>   <a href="#">Instagram</a>   <a href="#">linkdin</a>  <a href="#">Twitter</a></h4></ul>
        </div>
        <div class="footer_sub_3">
            <center>
            <h2>Subscribe Us</h2>
        <input type="text" name="subs" placeholder="Enter your email" class="subs">
                <input type="submit" name="submit_btn" value="subscribe" class="sub_btn">
                <p class="sub_p">Enter your Email id to get notifications from us.</p>
            </center>
        </div>
        </div>
        </div>
    </body>
</html>