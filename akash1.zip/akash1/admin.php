<html>
    <head>
        <title>login-Sky grocerer</title>
        <link rel="stylesheet" type="text/css" href="login.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
      <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>.</p>
</div>
</div>
<div id="main-header">
<div id="logo">
<span id="ist">SKY</span><span id="iist">Grocerer.com</span>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="#">Cart</a></li>
        <li><a href="">Login</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="index.html">Home</a>
        <a href="#">New launches</a>
        <a href="organic.html">Organic</a>
        <a href="#">About Us</a>
        </nav>
        <h2><center>Admin Login</center></h2>
        <form method="POST" action="adminlogin.php">
        <div class="boxed">
<div id="containe">   
    <h3>Login in to your account</h3>
<input class="text" name="email" placeholder="Enter Email" required>
    <input class="password" name="pass" type="password" placeholder="Enter Password" required>
    <div id="forgot">
    <a href="#"></a><br>
        </div>
        <input class="submit" type="submit" name="submit" value="Login">
    <h5>.</h5>
    <div class="signup">
    <a href="signup.html"></a> &nbsp; &nbsp; &nbsp;
        &nbsp; &nbsp; &nbsp; <a href=""></a>
    </div>
   <div class="info">
 <h3> You will love to shop with us</h3>
<h4>- Wide selection of products<br>
    <br>
- Quality and service you'll love<br>
    <br>
    - On time delivery guarantee</h4>
    </div>
    </div>
        </div>
        </form>
        </div>
         <div id="footer">
    <div class="container">
        <div class="footer_sub">
            <h2>About</h2>
            <h4>Online grocery shopping in India</h4>
            <p>This is an E-commerce webite designed in HTML and CSS using Java script also.Order online. All your favourite products from the low price online supermarket for grocery home delivery in Jaipur Lowest prices guaranteed on Patanjali, Aashirvaad, Maggi, Saffola, Fortune, Nestle, Amul, Surf Excel,Haldiram's and others.</p>
            <h4>One stop shop for all your daily needs</h4>
            <p>Sky grocerer is low-price online supermarket that allows you to order products across categories like grocery,and gets them delivered to your doorstep.</p>
        </div>
        <div class="footer_sub_2">
             <h2>Social links:</h2>
        <ul><h4> <a href="#">Facebook</a>   <a href="#">Instagram</a>   <a href="#">linkdin</a>  <a href="#">Twitter</a></h4></ul>
        </div>
        <div class="footer_sub_3">
            <center>
            <h2>Subscribe Us</h2>
        <input type="text" name="subs" placeholder="Enter your email" class="subs">
                <input type="submit" name="submit_btn" value="subscribe" class="sub_btn">
                <p class="sub_p">Enter your Email id to get notifications from us.</p>
            </center>
        </div>
        </div>
        </div>
    </body>
</html>