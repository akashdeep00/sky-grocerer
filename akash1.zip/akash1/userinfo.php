<?php
session_start();
if (isset($_SESSION['email'])){
$email=$_SESSION['email'];
}
if (isset($_SESSION['pass'])){
$pass=$_SESSION['pass'];
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "akash";
$a=$_SESSION['product'];
$_SESSION['product']=$a;
                    $b=$_SESSION['price'];
                    $_SESSION['price']=$b;


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstname,lastname from `data` where `email`= '$email' AND `password`= '$pass';";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
  
     print  '<h3>' . "Account   --  ". $row["firstname"]. " " . $row["lastname"]."" . '</h3>'; 
    }
} else {
    echo "0 results";
}
$conn->close();
    ?>
<html>
    <head>   <link rel="stylesheet" type="text/css" href="info.css"></head>
<body>
       <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>grocery store</p>
<a href="#">Guest</a><a href="#">Consumer</a><a href="#">Download App</a><a href="#">Help</a>
</div>
</div>
<div id="main-header">
<div id="logo">
<span id="ist">SKY</span><span id="iist">Grocerer.com</span>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="#">Cart</a></li>
        <li><a href="logout.php">Logout</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="home.php">Home</a>
        <a href="#">New launches</a>
        <a href="organic.php">Organic</a>
             </nav>
        <div class="boxed">
    <form method="POST" action="checkout.php">

        <h2>
             <b>Name  </b>   <input class="text1" name="nam1" placeholder="Name"required><br><br>
             <b>Email</b><input class="text3" name="nam3" placeholder="Email" required><br><br>
             <b>Mobile No.</b><input class="mobileno" type="number" name="nam5" placeholder="Mobile no." required><br><br>
            <b>Address</b><input class="address" type="text" name="address" placeholder="Address" required><br><br>
            <b>Pincode</b><input class="pincode" type="pincode" name="pincode" placeholder="Pincode" required><br><br> 
              <input class="submitt" type="submit" name="submit" value="Checkout">
        </h2>  </form>
            </div></div>
    </body></html>