


    <!DOCTYPE html>
    <html>
    <head>
    	<title></title>
    </head>
    <body>
    <h2 style="color:brown;">Search user:</h2><form method="POST" action="adminshow1.php"><input class="text" name="email" placeholder="Enter Email" required><input class="submit" type="submit" name="submit" value="Search"></form><br>
    </body>
    </html>