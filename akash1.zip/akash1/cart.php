<?php
session_start();
if (isset($_SESSION['email'])){
$email=$_SESSION['email'];
}
if (isset($_SESSION['pass'])){
$pass=$_SESSION['pass'];
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "akash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstname,lastname from `data` where `email`= '$email' AND `password`= '$pass';";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
  
     print  '<h3>' . "Account   --  ". $row["firstname"]. " " . $row["lastname"]."" . '</h3>'; 
    }
} else {
    echo "0 results";
}
$conn->close();
    ?>
<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="cart.css">
</head>
    <body>
        
      <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>.</p>
</div>
</div>
<div id="main-header">
<div id="logo">
    <a href="home.php" style="text-decoration:none;"><span id="ist">SKY</span><span id="iist">Grocerer.com</span></a>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="#">Cart</a></li>
        <li><a href="logout.php">Logout</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="home.php">Home</a>
        <a href="organic.php">New launches</a>
        <a href="organic.php">Organic</a>
        <a href="contact.php">Contact Us</a>
        </nav>
         <div class="fea">
             <h1><center>Shopping Cart</center></h1><br />
         </div>
        <form method="POST" action="userinfo.php">
        <div class="boxed">
         <div class="body">
             <h3><i>
                 

                 
            
      <?php
                 
$a=$_SESSION['product'];
$_SESSION['product']=$a;
                    $b=$_SESSION['price'];
                    $_SESSION['price']=$b;
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cart";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM `cart` WHERE 1";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
  
     print  '<h3>' . " ". $row["product"]. " " . $row["price"]."" . '</h3>'; echo"<a href='delete.php'>remove</a>";
} 
      
    }else {
    echo "0 results";
}
$conn->close();
    ?>           
                 
                 
                 </i></h3>
         </div>
             <input class="submit" type="submit" name="submit" value="Buy Now">
        </div>
        </form>
            </div>
    </body>
</html>