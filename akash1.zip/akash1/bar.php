<?php
session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="akash";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die("connection failed:".mysqli_connect_error());
}
else
{
     
    $ab="SELECT count(count) as c FROM orderdata  WHERE day > DATE_SUB(NOW(), INTERVAL 1 DAY);";
     $abc="SELECT count(count) as d FROM orderdata WHERE day > DATE_SUB(NOW(), INTERVAL 1 WEEK);";
     $abcd="SELECT count(count) as e FROM orderdata WHERE day > DATE_SUB(NOW(), INTERVAL 1 MONTH);";
         $result= mysqli_query($conn,$ab);
         if (mysqli_num_rows($result)>0)
          {
             while($row=mysqli_fetch_assoc($result))
             {
              ?>














<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['total', 'today', 'this week', 'this month'],
          ['time', <?php     echo $row['c'];
             }
                         
         }


}

?>   ,<?php $result1= mysqli_query($conn,$abc);
         if (mysqli_num_rows($result1)>0)
          {
             while($row=mysqli_fetch_assoc($result1))
             {
               echo $row['d'];
             }
                         
         }



?>
 , <?php $result2= mysqli_query($conn,$abcd);
         if (mysqli_num_rows($result2)>0)
          {
             while($row=mysqli_fetch_assoc($result2))
             {
               echo $row['e'];
             }
                         
         }



?>],
        ]);

        var options = {
          chart: {
            title: 'Company Performance',
            subtitle: 'Total sale',
          },
          bars: 'horizontal' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
          google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);
    </script>
  </head>
  <body>
    <div id="barchart_material" style="width: 900px; height: 500px;"></div>
  </body>
</html>