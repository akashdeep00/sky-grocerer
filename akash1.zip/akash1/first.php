<?php
       echo "<script>alert('First Login to your account');
        window.location.href='login1.php'</script>";
?>