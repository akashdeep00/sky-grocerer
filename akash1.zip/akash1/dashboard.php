﻿<?php
session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="akash";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die("connection failed:".mysqli_connect_error());
}
else
{
    $query="SELECT count(count) as c from `data`;"; 
     $abc="SELECT count(count) as d from `orderdata`;"; 
     $abcd="SELECT count(count) as e FROM orderdata  WHERE day > DATE_SUB(NOW(), INTERVAL 1 DAY);";
     $abcde="SELECT count(count) as f FROM orderdata WHERE day > DATE_SUB(NOW(), INTERVAL 1 WEEK);";
     $abcdef="SELECT count(count) as g FROM orderdata WHERE day > DATE_SUB(NOW(), INTERVAL 1 MONTH);";
      $feedc="SELECT count(name) as h from `feed`;"; 
         $result= mysqli_query($conn,$query);
         if (mysqli_num_rows($result)>0)
          {
             while($row=mysqli_fetch_assoc($result))
             {
      ?>










<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>Dashboard | Sky Grocerer Admin</title>
    <link rel="stylesheet" type="text/css" href="css/reset.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="css/text.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="css/grid.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="css/layout.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="css/nav.css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" type="text/css" href="css/ie6.css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
    <!-- BEGIN: load jquery -->
    <script src="js/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/jquery-ui/jquery.ui.core.min.js"></script>
    <script src="js/jquery-ui/jquery.ui.widget.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.ui.accordion.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.effects.core.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui/jquery.effects.slide.min.js" type="text/javascript"></script>
    <!-- END: load jquery -->
    <!-- BEGIN: load jqplot -->
    <link rel="stylesheet" type="text/css" href="css/jquery.jqplot.min.css" />
    <!--[if lt IE 9]><script language="javascript" type="text/javascript" src="js/jqPlot/excanvas.min.js"></script><![endif]-->
    <script language="javascript" type="text/javascript" src="js/jqPlot/jquery.jqplot.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.barRenderer.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.pieRenderer.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.categoryAxisRenderer.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.highlighter.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqPlot/plugins/jqplot.pointLabels.min.js"></script>
    <!-- END: load jqplot -->
    <script src="js/setup.js" type="text/javascript"></script>
    <script type="text/javascript">

        $(document).ready(function () {
            setupDashboardChart('chart1');
            setupLeftMenu();
			setSidebarHeight();


        });
    </script>
</head>
<body>
    <div class="container_12">
        <div class="grid_12 header-repeat">
            <div id="branding">
                <div class="floatleft">
                    <h3 style="color:cadetblue;">Sky Grocerer</h3></div>
                <div class="floatright">
                    <div class="floatleft">
                        <img src="img/img-profile.jpg" alt="Profile Pic" /></div>
                    <div class="floatleft marginleft10">
                        <ul class="inline-ul floatleft">
                            <li>Hello Admin</li>
                            <li><a href="index.html">Logout</a></li>
                        </ul>
                        <br />
                        <span class="small grey">Logged in</span>
                    </div>
                </div>
                <div class="clear">
                </div>
            </div>
        </div>
        <div class="clear">
        </div>
        <div class="grid_12">
            <ul class="nav main">
                <li class="ic-dashboard"><a href="dashboard.php"><span>Dashboard</span></a> </li>
				<li class="ic-grid-tables"><a href="bar.php"><span>Graph</span></a></li>
                <li class="ic-charts"><a href="piechart.html"><span>Data</span></a></li>
                <li class="ic-gallery dd"><a href="#"><span>Image Galleries</span></a>
                </li>
                <li class="ic-notifications"><a href="notifications.html"><span>Notifications</span></a></li>

            </ul>
        </div>
        <div class="clear">
        </div>
        <div class="grid_2">
            <div class="box sidemenu">
                <div class="block" id="section-menu">
                    <ul class="section menu">
                        <li><a class="menuitem">User</a>
                            <ul class="submenu">
                                <li><a href="adminshow.php">Search User</a> </li>
                                <li><a>Delete User</a> </li>
                              
                            </ul>
                        </li>
                        <li><a class="menuitem">Add Products</a>
                            <ul class="submenu">
                                <li><a href="adminadd.php">Organic</a> </li>
                                <li><a>Daily Essential</a> </li>
                                <li><a>Indian grocery</a> </li>
                                <li><a>fine-teas</a> </li>
                                <li><a>Confectionarie</a> </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="grid_10">
            <br>
            <br>
            <br>
            <br>
            <div class="box round">
                <h2>
                    Figures</h2>
                <div class="block">
                    <div class="stat-col">
                        <span>Total user</span>
                        <p class="purple">
                            <?php
                                     echo $row['c'];
             }
                         
         }


}

?>
</p>
                    </div>
                    <div class="stat-col">
                        <span>Total order</span>
                        <p class="yellow">
                            <?php
                             $result1= mysqli_query($conn,$abc);
         if (mysqli_num_rows($result1)>0)
          {
             while($row=mysqli_fetch_assoc($result1))
             {
                 echo $row['d'];
             }
                         
         }


      ?></p>
                    </div>
                    <div class="stat-col">
                        <span>Cancelled order</span>
                        <p class="green">
                            0</p>
                    </div>
                    <div class="stat-col">
                        <span>Today's Order</span>
                        <p class="blue">
                                               <?php
                             $result2= mysqli_query($conn,$abcd);
         if (mysqli_num_rows($result2)>0)
          {
             while($row=mysqli_fetch_assoc($result2))
             {
                 echo $row['e'];
             }
                         
         }


      ?></p>
                    </div>
                    <div class="stat-col">
                        <span>This Week Order</span>
                        <p class="red">
                             <?php
                             $result3= mysqli_query($conn,$abcde);
         if (mysqli_num_rows($result3)>0)
          {
             while($row=mysqli_fetch_assoc($result3))
             {
                 echo $row['f'];
             }
                         
         }


      ?>
                            </p>
                    </div>
                    <div class="stat-col">
                        <span>This Month Order</span>
                        <p class="purple">
                            <img src="img/icon-direction.png" alt="" />&nbsp;

                      <?php
                             $result4= mysqli_query($conn,$abcdef);
         if (mysqli_num_rows($result4)>0)
          {
             while($row=mysqli_fetch_assoc($result4))
             {
                 echo $row['g'];
             }
                         
         }


      ?>

                        </p>
                    </div>
                    <div class="stat-col last">
                        <span>Total Feedback</span>
                        <p class="darkblue">
                            
                             <?php
                             $result5= mysqli_query($conn,$feedc);
         if (mysqli_num_rows($result5)>0)
          {
             while($row=mysqli_fetch_assoc($result5))
             {
                 echo $row['h'];
             }
                         
         }


      ?>
                            </p>
                    </div>
                    <div class="clear">
                    </div>
                </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
AD
        </p>
    </div>
</body>
</html>
