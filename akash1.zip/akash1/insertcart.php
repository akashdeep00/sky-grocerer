<?php
session_start();
$a=$_POST['product'];
$b=$_POST['price'];
$_SESSION['product']=$a;
$_SESSION['price']=$b;
$servername="localhost";
$username="root";
$password="";
$dbname="cart";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("connection failed:".mysqli_connect_error());
}
else
{
	$sql="insert into `cart`(`product`,`price`) values('$a','$b');";
	$var=mysqli_query($conn,$sql);
	if($var)
	{
		 echo "<script>
        window.location.href='cart.php'</script>";
	}
	else
	{
		echo "Error:".$sql."<br>".mysqli_error($conn);
	}
}
mysqli_close($conn);
?>
      