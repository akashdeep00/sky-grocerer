<?php
$a=$_POST['nam1'];
$b=$_POST['nam3'];
$c=$_POST['nam4'];
$d=$_POST['star'];
$servername="localhost";
$username="root";
$password="";
$dbname="akash";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("connection failed:".mysqli_connect_error());
}
else
{
	$sql="insert into `feed`(`name`,`email`,`comments`,`star`) values('$a','$b','$c','$d');";
	$var=mysqli_query($conn,$sql);
	if($var)
	{
		echo "<script>alert('Thankyou for Feedback');
        window.location.href='contact.html'</script>";
	}
	else
	{
		echo "Error:".$sql."<br>".mysqli_error($conn);
	}
}
mysqli_close($conn);
?>