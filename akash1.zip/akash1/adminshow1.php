<?php
$email=$_POST['email'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "akash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstname,lastname,mobileno from `data` where `email`= '$email';";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
  
     print  '<h3>' . "User name  --  ". $row["firstname"]. " " . $row["lastname"]."  ". $row["mobileno"]. "" . '</h3>'; 
    }
} 
$conn->close();
    ?>






    <?php 
					$conn=mysqli_connect("localhost","root","","akash");
					$sql1="SELECT * from `orderdata` where `email`='$email';";

					$result1=mysqli_query($conn,$sql1);
					if ($result1) { ?>
						<br><br><br>
						<div class="container">
							<table border="2">
								<tr>
									<th colspan="3">orders</th>
								</tr>
								<tr>
									<th>product</th>
									<th>price</th>
									<th>day</th>
								</tr>
							<?php while ($row=mysqli_fetch_assoc($result1)){?>
								<tr>
									<td><?php echo $row["product"]; ?></td>
									<td><?php echo $row["price"]; ?></td>
									<td><?php echo $row["day"]; ?></td>
								</tr>
							<?php } ?>
						</table>
						</div>
				<?php	}
				 	

				?>
		</div>
</div>

</body>
</html>