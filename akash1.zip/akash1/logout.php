<?php
session_start();
session_unset();
  echo "<script>alert('Logged out');
        window.location.href='index.html'</script>";
?>