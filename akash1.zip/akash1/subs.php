<?php
   echo "<script>alert('Thankyou for subscrising us!');
        window.location.href='index.html'</script>";
?>