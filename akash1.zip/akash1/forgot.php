<?php
$email=$_POST['email'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "akash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
else{}
$sql = "SELECT password from `data` where `email`= '$email';";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
  
     print  '<h3>' . "password   --  ". $row["password"]. "  '</h3>'; 
    }
} 
$conn->close();
    ?>