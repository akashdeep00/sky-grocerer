<?php
session_start();
$d=$_SESSION['nam3'];
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'akashdeep2000.admonu@gmail.com';                 // SMTP username
    $mail->Password = 'akasdee99';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('noreply@poornima.org', 'Akash Deep');
    $mail->addAddress("$d");               // Name is optional
    $mail->addReplyTo('akashdeep2000.admonu@gmail.com', 'Information');
    $mail->addCC('cc@example.com');
    $mail->addBCC('bcc@example.com');

    
    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Sky Grocerer';
    $mail->Body    = 'Thankyou your order is successully placed.For any queries,feel free call<b>Akash deep</b> (8873994343).';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
   echo "<script>alert('Order Placed');
        window.location.href='home.php'</script>";
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
