
<?php
session_start();
if (isset($_SESSION['email'])){
$email=$_SESSION['email'];
}
if (isset($_SESSION['pass'])){
$pass=$_SESSION['pass'];
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "akash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstname,lastname from `data` where `email`= '$email' AND `password`= '$pass';";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          print  '<h3>' . "Account   --  ". $row["firstname"]. " " . $row["lastname"]."" . '</h3>'; 

    }
} else {
    echo "0 results";
}
$conn->close();
    ?>
<html>
    <head>
        <title>Daily Essential-Sky grocerer</title>
        <link rel="stylesheet" type="text/css" href="organic.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
      <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>grocery store</p>
<a href="#">Guest</a><a href="#">Consumer</a><a href="#">Download App</a><a href="#">Help</a>
</div>
</div>
<div id="main-header">
<div id="logo">
<span id="ist">SKY</span><span id="iist">Grocerer.com</span>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="#">Cart</a></li>
        <li><a href="logout.php">Logout</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="home.php">Home</a>
        <a href="#">New launches</a>
        <a href="organic.php">Organic</a>
        <a href="#">Gift cards</a>
        <a href="#">Orders</a>
        </nav>
        
        <div class="fea">
        <h2><center>Daily Essentials</center></h2>
            <hr>
        </div>

        <div class="prod-container">
        <div class="prod-box">
            <img src="images/baddam.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">
                                    <form method="POST" action="insertcart.php">
                <p>Baddam pista 400g</p><input type="hidden" name="product" value="Baddam pista 400g">
                    <p style="color:#fff;font-weight:bold;">price : 260</p><input type="hidden" name="price" value="RS 260">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div>
             <div class="prod-box">
            <img src="images/amulmilk.JPG" alt="Arhar dal">
            <div class="prod-trans">
                <div class="prod-feature">
                                                        <form method="POST" action="insertcart.php">

                <p>Amul Gold Milk 1L</p><input type="hidden" name="product" value="Amul Gold Milk 1L">
                    <p style="color:#fff;font-weight:bold;">price : 62</p><input type="hidden" name="price" value="RS 62">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/tata.webp" alt="Tata salt">
            <div class="prod-trans">
                <div class="prod-feature">
                                                        <form method="POST" action="cart.php">

                <p>Tata salt 1kg</p><input type="hidden" name="product" value="Tata salt 1kg">
                    <p style="color:#fff;font-weight:bold;">price : 19</p><input type="hidden" name="price" value="RS 19">
                    <input type="submit" value="Add to cart">
                    </form>`
                                                            </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/kinder.jpg" alt="india gate">
            <div class="prod-trans">
                <div class="prod-feature">   <form method="POST" action="cart.php">
                <p>Kinder joy</p><input type="hidden" name="product" value="Kinder Joy">
                    <p style="color:#fff;font-weight:bold;">price : 40</p><input type="hidden" name="price" value="RS 40">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/for.jpg" alt="fortune">
            <div class="prod-trans">
                <div class="prod-feature">  <form method="POST" action="cart.php">
                <p>Fortune soyabean oil 1lt.</p><input type="hidden" name="product" value="Fortune soyabean oil 1lt.">
                    <p style="color:#fff;font-weight:bold;">price : 120</p><input type="hidden" name="price" value="RS 120">
                    <input type="submit" value="Add to cart">
                    </form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/pro_211408.webp" alt="surf excel">
            <div class="prod-trans">
                <div class="prod-feature"> <form method="POST" action="cart.php">
                <p>Surf excel 3*2kg</p><input type="hidden" name="product" value="Surf excel 3*2kg">
                    <p style="color:#fff;font-weight:bold;">price : 960</p><input type="hidden" name="price" value="RS 960">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/col.webp" alt="colgate">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                <p>Colgate herbal 200gm</p><input type="hidden" name="product" value="Colgate herbal 200gm">
                    <p style="color:#fff;font-weight:bold;">price : 88</p><input type="hidden" name="price" value="RS 88">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/parle.jpg" alt="parle">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                <p>Parle-G 800gm</p><input type="hidden" name="product" value="Parle-G 800gm">
                    <p style="color:#fff;font-weight:bold;">price : 60</p><input type="hidden" name="price" value="RS 60">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/cofee.webp" alt="coffee">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                <p>Nescafe coffee 200gm</p><input type="hidden" name="product" value="Nescafe coffee 200gm">
                    <p style="color:#fff;font-weight:bold;">price : 250</p><input type="hidden" name="price" value="RS 250">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div> <div class="prod-box">
            <img src="images/tide.webp" alt="tide">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                               <p>Tide 6kg</p><input type="hidden" name="product" value="Tide 6kg">

                    <p style="color:#fff;font-weight:bold;">price : 484</p><input type="hidden" name="price" value="RS 484">

                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div>
             <div class="prod-box">
            <img src="images/boubon.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature">                <form method="POST" action="cart.php">
                <p>Bourbon 150g</p><input type="hidden" name="product" value="Bourbon 150g">
                    <p style="color:#fff;font-weight:bold;">price : 28</p><input type="hidden" name="price" value="RS 28">
                    <input type="submit" value="Add to cart"></form></div>
                </div>
            </div><div class="prod-box">
            <img src="images/magii.JPG" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                <p>Magii 420g</p><input type="hidden" name="product" value="Magii 420g">
                    <p style="color:#fff;font-weight:bold;">price : 65</p><input type="hidden" name="price" value="RS 65">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div><div class="prod-box">
            <img src="images/amul.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                <p>Amul butter 100g</p><input type="hidden" name="product" value="Amul butter 100g">
                    <p style="color:#fff;font-weight:bold;">price : 46</p><input type="hidden" name="price" value="RS 46">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div><div class="prod-box">
            <img src="images/bour.jpg" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                <p>Bourvita 1kg</p><input type="hidden" name="product" value="Bourvita 1kg">
                    <p style="color:#fff;font-weight:bold;">price : 378</p><input type="hidden" name="price" value="RS 378">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div> 
            <div class="prod-box">
            <img src="images/thumsup.JPG" alt="Dove shampoo">
            <div class="prod-trans">
                <div class="prod-feature"><form method="POST" action="cart.php">
                <p>Thums up 600ml</p><input type="hidden" name="product" value="Thums up 600ml">
                    <p style="color:#fff;font-weight:bold;">price : 38</p><input type="hidden" name="price" value="RS 38">
                    <input type="submit" value="Add to cart"></form>
                </div>
            </div>
                 </div>
                 
               </div>
        <div id="footer">
    <div class="container">
        <div class="footer_sub">
            <h2>About</h2>
            <h4>Online grocery shopping in India</h4>
            <p>This is an E-commerce webite designed in HTML and CSS using Java script also.Order online. All your favourite products from the low price online supermarket for grocery home delivery in Jaipur Lowest prices guaranteed on Patanjali, Aashirvaad, Maggi, Saffola, Fortune, Nestle, Amul, Surf Excel,Haldiram's and others.</p>
            <h4>One stop shop for all your daily needs</h4>
            <p>Sky grocerer is low-price online supermarket that allows you to order products across categories like grocery,and gets them delivered to your doorstep.</p>
        </div>
        <div class="footer_sub_2">
             <h2>Social links:</h2>
        <ul><h4> <a href="#">Facebook</a>   <a href="#">Instagram</a>   <a href="#">linkdin</a>  <a href="#">Twitter</a></h4></ul>
        </div>
        <div class="footer_sub_3">
            <center>
            <h2>Subscribe Us</h2>
        <input type="text" name="subs" placeholder="Enter your email" class="subs">
                <input type="submit" name="submit_btn" value="subscribe" class="sub_btn">
                <p class="sub_p">Enter your Email id to get notifications from us.</p>
            </center>
        </div>
            </div>
        </div>
    
        </div>
    </body>
</html>
    