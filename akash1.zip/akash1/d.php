<?php
session_start();
if (isset($_SESSION['email'])){
$email=$_SESSION['email'];
}
if (isset($_SESSION['pass'])){
$pass=$_SESSION['pass'];
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "akash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstname,lastname from `data` where `email`= '$email' AND `password`= '$pass';";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "" . $row["firstname"]. " " . $row["lastname"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
    ?>