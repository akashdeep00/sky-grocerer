<?php
session_start();
$a=$_SESSION['product'];
$servername="localhost";
$username="root";
$password="";
$dbname="cart";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("connection failed:".mysqli_connect_error());
}
else
{
  	$query="DELETE FROM `cart` WHERE `product`='$a';"; 
         $result= mysqli_query($conn,$query);
         if (mysqli_num_rows($result)>0)
          {
             while($row=mysqli_fetch_assoc($result))
             {
                  echo "<script>
        window.location.href='cart.php'</script>";
             }
                         
         }

         else{
           echo "<script>
        window.location.href='cart.php'</script>";
         }

}
mysqli_close($conn);
?>