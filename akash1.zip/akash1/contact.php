
<?php
session_start();
if (isset($_SESSION['email'])){
$email=$_SESSION['email'];
}
if (isset($_SESSION['pass'])){
$pass=$_SESSION['pass'];
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "akash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstname,lastname from `data` where `email`= '$email' AND `password`= '$pass';";
$result = $conn->query($sql);
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          print  '<h3>' . "Account   --  ". $row["firstname"]. " " . $row["lastname"]."" . '</h3>'; 

    }
} else {
    echo "0 results";
}
$conn->close();
    ?>
<html>
    <head>
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
        <title>Daily Essential-Sky grocerer</title>
        <link rel="stylesheet" type="text/css" href="contact.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
      <div id="wrapper">
<div id="header">
<div id="subheader">
<div class="container">
<p>.</p>
</div>
</div>
<div id="main-header">
<div id="logo">
<span id="ist">SKY</span><span id="iist">Grocerer.com</span>
</div>
    <div id="search">
    <form action="">
       
        <input class="search-area" name="text" placeholder="search products">
        <input class="search-btn" type="submit" name="submit" value="SEARCH">
        </form>
    </div>
    <div id="user-menu">
    <li><a href="cart.php">Cart</a></li>
        <li><a href="logout.php">Logout</a></li>
    </div>
    </div>
          </div>
    </div>
    <div id="navigation">
    <nav>
        <a href="home.php">Home</a>
        <a href="organic.php">New launches</a>
        <a href="organic.php">Organic</a>
        </nav>
        
        
        
 <div class="boxeds">
         <div id="sign">
             <center><h1>Feedback</h1></center>
             <hr>
             <form method="POST" action="contactus.php">
            <h2> <b>Name  </b>   <input class="text1" name="nam1" placeholder="Name"required><br><br>
             <b>Email</b><input class="text3" name="nam3" placeholder="Email" required><br><br>
              <b>Comments</b><input class="passw" name="nam4" placeholder="Comments" required>
        
                 
      <div class="stars">
 
    <input class="star star-5" id="star-5" type="radio" name="star"/>
    <label class="star star-5" for="star-5"></label>
    <input class="star star-4" id="star-4" type="radio" name="star"/>
    <label class="star star-4" for="star-4"></label>
    <input class="star star-3" id="star-3" type="radio" name="star"/>
    <label class="star star-3" for="star-3"></label>
    <input class="star star-2" id="star-2" type="radio" name="star"/>
    <label class="star star-2" for="star-2"></label>
    <input class="star star-1" id="star-1" type="radio" name="star"/>
    <label class="star star-1" for="star-1"></label>
</div>
                 </h2>
                 
                 
              <input class="submitt" type="submit" name="submit" value="Send">
              </form>
  
            </div>
        </div>
        
        <center><h2>Developers</h2></center>
    <hr><hr>
    <div class="image">
        <img src="akash.jpg" style="margin:0 320px;">
            <h2 style="margin:10 410px;">Akash Deep
        <br>CS(2nd year)</h2>
        <h3> <a href="akash_resume.docx" style="margin:0 430px;">Resume</a></h3>
        </div>
        
         <div class="image">
        <img src="suraj%20(1).jpg" style="margin:-700 820px;">
            <h2 style="margin:-105 850 30px;">Suraj Kumar
        <br>CS(2nd year)</h2>
        <h3> <a href="Resume" style="margin:-0 900px;">Resume</a></h3>
        </div>
        
        
        
         <div id="footer">
    <div class="container">
        <div class="footer_sub">
            <h2>About</h2>
            <h4>Online grocery shopping in India</h4>
            <p>This is an E-commerce webite designed in HTML and CSS using Java script also.Order online. All your favourite products from the low price online supermarket for grocery home delivery in Jaipur Lowest prices guaranteed on Patanjali, Aashirvaad, Maggi, Saffola, Fortune, Nestle, Amul, Surf Excel,Haldiram's and others.</p>
            <h4>One stop shop for all your daily needs</h4>
            <p>Sky grocerer is low-price online supermarket that allows you to order products across categories like grocery,and gets them delivered to your doorstep.</p>
        </div>
        <div class="footer_sub_2">
             <h2>Social links:</h2>
        <ul><h4> <a href="#">Facebook</a>   <a href="#">Instagram</a>   <a href="#">linkdin</a>  <a href="#">Twitter</a></h4></ul>
        </div>
        <div class="footer_sub_3">
            <center>
            <h2>Subscribe Us</h2>
        <input type="text" name="subs" placeholder="Enter your email" class="subs">
                <input type="submit" name="submit_btn" value="subscribe" class="sub_btn">
                <p class="sub_p">Enter your Email id to get notifications from us.</p>
            </center>
        </div>
            </div>
        </div>
    
        </div>
    </body>
</html>
    